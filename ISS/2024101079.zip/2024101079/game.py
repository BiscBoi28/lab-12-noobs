import pygame
import random
import os

# Initialize Pygame
pygame.init()

# Set up display
WIDTH = 600
HEIGHT = 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))

# Get script directory for reliable path handling
script_dir = os.path.dirname(os.path.abspath(__file__))

# Load images with proper path handling
phineas_image = pygame.image.load(os.path.join(script_dir, "assets", "images", "phineas_flipped.png"))
isabella_image = pygame.image.load(os.path.join(script_dir, "assets", "images", "isabella.png"))

# Initialize game variables
running = True
clock = pygame.time.Clock()
gravity = 500

# Phineas variables
phineas_x = 0
phineas_y = 0
phineas_vx = 20
phineas_vy = 0
p_width = phineas_image.get_width()
p_height = phineas_image.get_height()
score_phineas = 0

# Isabella variables
isabella_x = 500
isabella_y = 0
isabella_vx = 20
isabella_vy = 0
i_width = isabella_image.get_width()
i_height = isabella_image.get_height()
score_isabella = 0

# Block lists
green_rects = []  # For Phineas
pink_rects = []   # For Isabella

# Main game loop
while running:
    dt = clock.tick(60) / 1000
    screen.fill((0, 0, 0))

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Get key states
    keys = pygame.key.get_pressed()

    # Phineas controls (Arrow keys + Space)
    if keys[pygame.K_SPACE]:
        phineas_vy = -400
    if keys[pygame.K_RIGHT]:
        phineas_x += phineas_vx
    if keys[pygame.K_LEFT]:
        phineas_x -= phineas_vx

    # Isabella controls (A/D for movement, W to jump)
    if keys[pygame.K_w]:
        isabella_vy = -400
    if keys[pygame.K_d]:
        isabella_x += isabella_vx
    if keys[pygame.K_a]:
        isabella_x -= isabella_vx

    # Generate blocks
    if random.randint(0, 2000) > 1897:
        green_rects.append(pygame.Rect(WIDTH, random.randint(0, HEIGHT-100), 10, 100))
    if random.randint(0, 2000) > 1900:
        pink_rects.append(pygame.Rect(WIDTH, random.randint(0, HEIGHT-100), 10, 100))

    # Update physics
    phineas_vy += gravity * dt
    phineas_y += phineas_vy * dt
    isabella_vy += gravity * dt
    isabella_y += isabella_vy * dt

    # Floor collision
    # Phineas floor collision
    if phineas_y > HEIGHT - p_height:
        phineas_y = HEIGHT - p_height
        phineas_vy = 0
    
    # Isabella floor collision
    if isabella_y > HEIGHT - i_height:
        isabella_y = HEIGHT - i_height
        isabella_vy = 0

    # Draw blocks
    for rect in green_rects:
        pygame.draw.rect(screen, (0, 255, 0), rect)
    for rect in pink_rects:
        pygame.draw.rect(screen, (255, 192, 203), rect)

    # Move blocks and check collisions
    phineas_rect = pygame.Rect(phineas_x, phineas_y, p_width, p_height)
    isabella_rect = pygame.Rect(isabella_x, isabella_y, i_width, i_height)

    # Handle green blocks (Phineas)
    for rect in green_rects[:]:
        rect.x -= 5
        if phineas_rect.colliderect(rect):
            green_rects.remove(rect)
            score_phineas += 1

    # Handle pink blocks (Isabella)
    for rect in pink_rects[:]:
        rect.x -= 5
        if isabella_rect.colliderect(rect):
            pink_rects.remove(rect)
            score_isabella += 1

    # Draw characters
    screen.blit(phineas_image, (phineas_x, phineas_y))
    screen.blit(isabella_image, (isabella_x, isabella_y))

    pygame.display.flip()

# Final scores
print(f"Phineas' score: {score_phineas}")
print(f"Isabella's score: {score_isabella}")

pygame.quit()