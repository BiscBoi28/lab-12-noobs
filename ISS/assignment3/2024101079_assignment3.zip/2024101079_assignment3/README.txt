I have attached the link of my website that I have published on github.io.
The site includes everything that was asked in question 1 along with my personal interests. 
I have given the option to download my cv as well. 
The console prints all the info as asked in question 2.
The text box will work with number of words less than 10000 as well as more than 10000.